"""
Strategy GLM-HMM
================

A GLM-HMM (Ashwood, Bolkan, Pillow-style latent-state model) adapted for the
specific structure of "which strategy explains the choice" data:

  - The outcome is categorical (direction of choice), but the *choice set
    varies trial to trial* (2, 3, or 4 legible directions).
  - Predictors are *alternative-specific*: each strategy points to a
    particular direction on a given trial, so the feature for
    (trial t, alternative a) is a vector of 0/1 (or continuous) indicators
    "does strategy k predict alternative a on trial t".

Standard GLM-HMM code (e.g. the Linderman-lab `ssm` package used in the
Ashwood/Pillow papers) assumes a fixed set of classes and trial-level
(not alternative-specific) covariates, which doesn't match this setup.
So the emission model here is a *conditional logit* (McFadden discrete
choice model) instead of a per-class softmax regression, embedded inside
an HMM over K latent states. Each state k carries its own weight vector
w_k over the strategy features; the weight on "strategy j" in state k is
literally "how much does strategy j drive choices while the animal is in
behavioral state k". The HMM's transition matrix tells you how sticky /
volatile each state is, and Viterbi/posterior decoding tells you which
trials the animal was likely using which strategy mixture.

Author: written for Balala's GridWorld / macaque choice-strategy analysis.
"""

import numpy as np
from scipy.special import logsumexp
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Forward-backward (Baum-Welch E-step) for a single session/sequence
# ---------------------------------------------------------------------------

def forward_backward(log_pi, log_A, log_B):
    """
    log_pi : (K,)      log initial state distribution
    log_A  : (K,K)     log_A[i,j] = log P(z_{t+1}=j | z_t=i)
    log_B  : (T,K)     log_B[t,k] = log P(choice_t | z_t=k)

    Returns
    -------
    gamma : (T,K)     P(z_t=k | all choices in session)
    xi    : (T-1,K,K) P(z_t=i, z_{t+1}=j | all choices in session)
    loglik: scalar    log P(choices in session | params)
    """
    T, K = log_B.shape

    log_alpha = np.zeros((T, K))
    log_alpha[0] = log_pi + log_B[0]
    for t in range(1, T):
        log_alpha[t] = logsumexp(log_alpha[t - 1][:, None] + log_A, axis=0) + log_B[t]
    loglik = logsumexp(log_alpha[-1])

    log_beta = np.zeros((T, K))
    for t in range(T - 2, -1, -1):
        log_beta[t] = logsumexp(log_A + (log_B[t + 1] + log_beta[t + 1])[None, :], axis=1)

    log_gamma = log_alpha + log_beta
    log_gamma -= logsumexp(log_gamma, axis=1, keepdims=True)
    gamma = np.exp(log_gamma)

    if T > 1:
        xi = np.zeros((T - 1, K, K))
        for t in range(T - 1):
            log_xi_t = (log_alpha[t][:, None] + log_A
                        + log_B[t + 1][None, :] + log_beta[t + 1][None, :])
            log_xi_t -= logsumexp(log_xi_t)
            xi[t] = np.exp(log_xi_t)
    else:
        xi = np.zeros((0, K, K))

    return gamma, xi, loglik


def viterbi(log_pi, log_A, log_B):
    """Most likely single state sequence (hard decoding) for one session."""
    T, K = log_B.shape
    log_delta = np.zeros((T, K))
    psi = np.zeros((T, K), dtype=int)

    log_delta[0] = log_pi + log_B[0]
    for t in range(1, T):
        scores = log_delta[t - 1][:, None] + log_A  # (K_prev, K_curr)
        psi[t] = np.argmax(scores, axis=0)
        log_delta[t] = np.max(scores, axis=0) + log_B[t]

    z = np.zeros(T, dtype=int)
    z[-1] = np.argmax(log_delta[-1])
    for t in range(T - 2, -1, -1):
        z[t] = psi[t + 1, z[t + 1]]
    return z


# ---------------------------------------------------------------------------
# Weighted conditional-logit log-likelihood + gradient (used in the M-step)
# ---------------------------------------------------------------------------

def _neg_weighted_loglik(w, X, mask, choice_idx, weights, l2=1e-3):
    """
    X          : (T, C, F) alternative-specific features (invalid entries: any value, masked out)
    mask       : (T, C) bool, True where alternative is a legible/available option
    choice_idx : (T,) int, index (0..C-1) of the chosen alternative
    weights    : (T,) responsibility of this state for each trial (gamma[:,k])
    """
    T = X.shape[0]
    logits = X @ w  # (T, C)
    logits = np.where(mask, logits, -np.inf)
    logZ = logsumexp(logits, axis=1)
    chosen_logit = logits[np.arange(T), choice_idx]
    ll = chosen_logit - logZ
    nll = -np.sum(weights * ll) + 0.5 * l2 * np.sum(w ** 2)
    return nll


def _grad_neg_weighted_loglik(w, X, mask, choice_idx, weights, l2=1e-3):
    T, C, F = X.shape
    logits = X @ w
    logits = np.where(mask, logits, -np.inf)
    m = np.max(logits, axis=1, keepdims=True)
    exp_logits = np.where(mask, np.exp(logits - m), 0.0)
    probs = exp_logits / exp_logits.sum(axis=1, keepdims=True)  # (T,C)

    onehot = np.zeros((T, C))
    onehot[np.arange(T), choice_idx] = 1.0

    diff = (onehot - probs) * weights[:, None]  # (T,C)
    grad = np.einsum('tc,tcf->f', diff, X)
    return -grad + l2 * w


# ---------------------------------------------------------------------------
# The GLM-HMM model
# ---------------------------------------------------------------------------

class StrategyGLMHMM:
    """
    K-state HMM with conditional-logit ("discrete choice") emissions.

    Parameters
    ----------
    n_states   : number of latent behavioral states (strategy regimes)
    n_features : number of alternative-specific features (typically = number
                 of candidate strategies, one 0/1 column each; can add extras
                 e.g. a "distance to goal" continuous feature per alternative)
    l2         : ridge penalty on each state's weight vector (stabilizes fits
                 with few trials per state / collinear strategies)
    """

    def __init__(self, n_states, n_features, l2=1e-3, seed=0):
        self.K = n_states
        self.F = n_features
        self.l2 = l2
        rng = np.random.default_rng(seed)
        self.log_pi = np.log(np.ones(n_states) / n_states)
        self.log_A = np.log(np.ones((n_states, n_states)) / n_states)
        self.W = 0.1 * rng.standard_normal((n_states, n_features))

    # -- emissions -----------------------------------------------------
    def emission_logprob(self, X, mask, choice_idx):
        """Returns (T,K) log P(choice_t | z_t=k) for every state k."""
        T = X.shape[0]
        logB = np.zeros((T, self.K))
        for k in range(self.K):
            logits = X @ self.W[k]
            logits = np.where(mask, logits, -np.inf)
            logZ = logsumexp(logits, axis=1)
            chosen_logit = logits[np.arange(T), choice_idx]
            logB[:, k] = chosen_logit - logZ
        return logB

    # -- EM --------------------------------------------------------------
    def e_step(self, sessions):
        all_gamma, all_xi = [], []
        total_ll = 0.0
        for s in sessions:
            logB = self.emission_logprob(s['X'], s['mask'], s['choice_idx'])
            gamma, xi, ll = forward_backward(self.log_pi, self.log_A, logB)
            all_gamma.append(gamma)
            all_xi.append(xi)
            total_ll += ll
        return all_gamma, all_xi, total_ll

    def m_step(self, sessions, all_gamma, all_xi):
        # initial-state distribution: average of each session's first gamma
        pi_new = np.mean([g[0] for g in all_gamma], axis=0)
        self.log_pi = np.log(pi_new + 1e-12)

        # transition matrix: pooled expected counts across sessions
        xi_sum = sum(xi.sum(axis=0) for xi in all_xi if xi.shape[0] > 0)
        gamma_sum = sum(g[:-1].sum(axis=0) for g in all_gamma if g.shape[0] > 1)
        if np.isscalar(xi_sum):  # no session had >1 trial
            xi_sum = np.ones((self.K, self.K))
            gamma_sum = np.ones(self.K) * self.K
        A_new = xi_sum / gamma_sum[:, None]
        self.log_A = np.log(A_new + 1e-12)

        # per-state weights: weighted conditional-logit MLE, pooled across sessions
        X_all = np.concatenate([s['X'] for s in sessions], axis=0)
        mask_all = np.concatenate([s['mask'] for s in sessions], axis=0)
        choice_all = np.concatenate([s['choice_idx'] for s in sessions], axis=0)
        gamma_all = np.concatenate(all_gamma, axis=0)

        for k in range(self.K):
            res = minimize(
                _neg_weighted_loglik, self.W[k],
                args=(X_all, mask_all, choice_all, gamma_all[:, k], self.l2),
                jac=_grad_neg_weighted_loglik, method='L-BFGS-B'
            )
            self.W[k] = res.x

    def fit(self, sessions, n_iter=200, tol=1e-4, verbose=True):
        prev_ll = -np.inf
        history = []
        for it in range(n_iter):
            gamma, xi, ll = self.e_step(sessions)
            self.m_step(sessions, gamma, xi)
            history.append(ll)
            if verbose and (it % 10 == 0 or it == n_iter - 1):
                print(f"  iter {it:3d}  loglik = {ll:.3f}")
            if abs(ll - prev_ll) < tol:
                if verbose:
                    print(f"  converged at iter {it}, loglik = {ll:.3f}")
                break
            prev_ll = ll
        return history

    # -- inference on new/held-out data ----------------------------------
    def posterior_states(self, sessions):
        """Soft state posteriors per session (list of (T,K) arrays)."""
        gamma, _, _ = self.e_step(sessions)
        return gamma

    def decode_states(self, sessions):
        """Hard (Viterbi) state sequence per session (list of (T,) arrays)."""
        out = []
        for s in sessions:
            logB = self.emission_logprob(s['X'], s['mask'], s['choice_idx'])
            out.append(viterbi(self.log_pi, self.log_A, logB))
        return out

    def score(self, sessions):
        """Total held-out log-likelihood (for model selection / cross-val)."""
        _, _, ll = self.e_step(sessions)
        return ll


def fit_with_restarts(n_states, n_features, sessions, n_restarts=5, l2=1e-3,
                       n_iter=200, tol=1e-4, verbose=False):
    """
    EM only finds a local optimum, and GLM-HMMs are notorious for bad ones
    (e.g. a state that never gets visited). Fit several random initializations
    and keep the one with highest training log-likelihood.
    """
    best_model, best_ll = None, -np.inf
    for r in range(n_restarts):
        m = StrategyGLMHMM(n_states, n_features, l2=l2, seed=r)
        hist = m.fit(sessions, n_iter=n_iter, tol=tol, verbose=verbose)
        if hist[-1] > best_ll:
            best_ll = hist[-1]
            best_model = m
        print(f"restart {r}: final loglik = {hist[-1]:.3f}")
    print(f"best final loglik = {best_ll:.3f}")
    return best_model


# ---------------------------------------------------------------------------
# Data prep: long-format dataframe -> padded arrays the model expects
# ---------------------------------------------------------------------------

def prepare_sessions(df, trial_col, direction_col, chosen_col,
                      strategy_cols, session_col=None):
    """
    df must be in LONG format: one row per (trial, legible direction), e.g.

        trial | direction | chosen | strat1 | strat2 | strat3
        1     | up        | 1      | 1      | 0      | 0
        1     | down      | 0      | 0      | 1      | 0
        1     | left      | 0      | 0      | 0      | 1
        2     | left      | 1      | 0      | 0      | 1
        2     | right     | 0      | 1      | 0      | 0

    Only include rows for directions that were actually legible/available
    on that trial -- that's how the varying 2-4 choice set is handled, no
    padding of "missing" directions needed at this stage.

    Parameters
    ----------
    trial_col     : column identifying the trial
    direction_col : column identifying the alternative (direction)
    chosen_col    : 1/0 column, 1 for the row that was chosen
    strategy_cols : list of column names, each a 0/1 (or continuous)
                    alternative-specific feature (e.g. "strat1_predicts")
    session_col   : optional column to split into separate HMM sequences
                    (state persists within a session, resets across sessions).
                    If None, the whole dataframe is treated as one session.

    Returns
    -------
    sessions : list of dicts with keys 'X' (T,Cmax,F), 'mask' (T,Cmax) bool,
               'choice_idx' (T,) int -- ready for StrategyGLMHMM.fit()
    """
    if session_col is None:
        df = df.copy()
        df['__session__'] = 0
        session_col = '__session__'

    sessions = []
    for _, sess_df in df.groupby(session_col, sort=True):
        trials = []
        for _, tdf in sess_df.groupby(trial_col, sort=True):
            trials.append(tdf)
        Cmax = max(len(t) for t in trials)
        F = len(strategy_cols)
        T = len(trials)

        X = np.zeros((T, Cmax, F))
        mask = np.zeros((T, Cmax), dtype=bool)
        choice_idx = np.zeros(T, dtype=int)

        for t, tdf in enumerate(trials):
            n_alt = len(tdf)
            X[t, :n_alt, :] = tdf[strategy_cols].to_numpy()
            mask[t, :n_alt] = True
            chosen_rows = np.where(tdf[chosen_col].to_numpy() == 1)[0]
            choice_idx[t] = chosen_rows[0]

        sessions.append({'X': X, 'mask': mask, 'choice_idx': choice_idx})

    return sessions

"""
Plotting helpers for StrategyGLMHMM results -- the standard figure types
from the Ashwood/Pillow line of papers, adapted to this model:

  1. plot_state_probs   - posterior P(state) over trials for one session
  2. plot_weights        - per-state strategy weights (which strategy
                            dominates in which state)
  3. plot_transition_matrix - state persistence / switching probabilities
"""
import numpy as np
import matplotlib.pyplot as plt


def plot_state_probs(gamma, ax=None, state_labels=None, title=None):
    """gamma: (T,K) posterior state probabilities for one session."""
    T, K = gamma.shape
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 2.5))
    for k in range(K):
        ax.plot(np.arange(T), gamma[:, k],
                label=(state_labels[k] if state_labels else f'state {k}'))
    ax.set_xlabel('trial')
    ax.set_ylabel('P(state)')
    ax.set_ylim(-0.02, 1.02)
    ax.legend(loc='upper right', frameon=False, fontsize=8)
    if title:
        ax.set_title(title)
    return ax


def plot_weights(W, strategy_labels, state_labels=None, ax=None, title=None):
    """W: (K,F) fitted per-state strategy weights."""
    K, F = W.shape
    if ax is None:
        _, ax = plt.subplots(figsize=(1.5 * K + 2, 4))
    x = np.arange(F)
    width = 0.8 / K
    for k in range(K):
        ax.bar(x + k * width, W[k], width=width,
               label=(state_labels[k] if state_labels else f'state {k}'))
    ax.set_xticks(x + width * (K - 1) / 2)
    ax.set_xticklabels(strategy_labels, rotation=30, ha='right')
    ax.set_ylabel('weight')
    ax.axhline(0, color='k', lw=0.5)
    ax.legend(frameon=False, fontsize=8)
    if title:
        ax.set_title(title)
    return ax


def plot_transition_matrix(log_A, state_labels=None, ax=None):
    A = np.exp(log_A)
    K = A.shape[0]
    if ax is None:
        _, ax = plt.subplots(figsize=(3 + 0.5 * K, 3 + 0.5 * K))
    im = ax.imshow(A, vmin=0, vmax=1, cmap='viridis')
    labels = state_labels if state_labels else [f's{k}' for k in range(K)]
    ax.set_xticks(range(K)); ax.set_xticklabels(labels)
    ax.set_yticks(range(K)); ax.set_yticklabels(labels)
    ax.set_xlabel('to state'); ax.set_ylabel('from state')
    for i in range(K):
        for j in range(K):
            ax.text(j, i, f'{A[i, j]:.2f}', ha='center', va='center',
                     color='white' if A[i, j] < 0.6 else 'black')
    plt.colorbar(im, ax=ax, fraction=0.046)
    return ax

"""
Sanity check: simulate an animal that alternates between two regimes
  - state 0 ("strategy-1 dominant"): choices driven mostly by strategy 1
  - state 1 ("strategy-2 dominant"): choices driven mostly by strategy 2
with sticky Markov switching between them, and 2-4 legible directions
per trial (so the choice set genuinely varies). Then fit StrategyGLMHMM
and check it recovers the true states and weights.
"""
import numpy as np
import pandas as pd
from strategy_glmhmm import StrategyGLMHMM, fit_with_restarts, prepare_sessions

rng = np.random.default_rng(0)

DIRECTIONS = ['up', 'down', 'left', 'right']
N_STRATEGIES = 3  # strat1, strat2, strat3
TRUE_W = np.array([
    [3.0, 0.2, 0.2],   # state 0: strategy 1 dominant
    [0.2, 3.0, 0.2],   # state 1: strategy 2 dominant
])
TRUE_A = np.array([[0.95, 0.05],
                    [0.08, 0.92]])
TRUE_PI = np.array([0.5, 0.5])

N_TRIALS = 3000


def simulate():
    rows = []
    z = rng.choice(2, p=TRUE_PI)
    true_states = np.zeros(N_TRIALS, dtype=int)

    for t in range(N_TRIALS):
        true_states[t] = z

        # 2-4 legible directions this trial
        n_legible = rng.choice([2, 3, 4], p=[0.2, 0.3, 0.5])
        legible = rng.choice(DIRECTIONS, size=n_legible, replace=False)

        # each strategy "points to" one of the legible directions at random
        strat_targets = rng.choice(legible, size=N_STRATEGIES, replace=True)

        # build alternative-specific features for this trial
        feats = np.zeros((n_legible, N_STRATEGIES))
        for j, target in enumerate(strat_targets):
            idx = np.where(legible == target)[0][0]
            feats[idx, j] = 1.0

        logits = feats @ TRUE_W[z]
        probs = np.exp(logits - logits.max())
        probs /= probs.sum()
        chosen = rng.choice(n_legible, p=probs)

        for a in range(n_legible):
            rows.append({
                'trial': t,
                'direction': legible[a],
                'chosen': int(a == chosen),
                'strat1': feats[a, 0],
                'strat2': feats[a, 1],
                'strat3': feats[a, 2],
            })

        z = rng.choice(2, p=TRUE_A[z])

    return pd.DataFrame(rows), true_states


def state_match_accuracy(true_states, decoded):
    # states are exchangeable (label switching), so check both permutations
    acc1 = np.mean(true_states == decoded)
    acc2 = np.mean(true_states == (1 - decoded))
    return max(acc1, acc2)


if __name__ == '__main__':
    df, true_states = simulate()
    print(f"Simulated {N_TRIALS} trials, {len(df)} trial-alternative rows")
    print(df.head(8))

    sessions = prepare_sessions(
        df, trial_col='trial', direction_col='direction',
        chosen_col='chosen', strategy_cols=['strat1', 'strat2', 'strat3']
    )
    print(f"\nn_sessions={len(sessions)}, first session T={sessions[0]['X'].shape[0]}, "
          f"Cmax={sessions[0]['X'].shape[1]}, F={sessions[0]['X'].shape[2]}")

    print("\nFitting 2-state GLM-HMM (5 random restarts)...")
    model = fit_with_restarts(n_states=2, n_features=3, sessions=sessions,
                               n_restarts=5, n_iter=150, verbose=False)

    print("\nTrue weights:\n", TRUE_W)
    print("Recovered weights:\n", model.W)

    print("\nTrue transition matrix:\n", TRUE_A)
    print("Recovered transition matrix:\n", np.exp(model.log_A))

    decoded = model.decode_states(sessions)[0]
    acc = state_match_accuracy(true_states, decoded)
    print(f"\nViterbi state-recovery accuracy (best label permutation): {acc:.3f}")

    assert acc > 0.85, "state recovery accuracy too low -- something's off"
    print("\nOK: model recovers ground-truth states and per-state strategy weights.")
